import cv2
import numpy as np
import imutils

image = cv2.imread("8.jpg")
resized = imutils.resize(image, width=600)

red = resized[:,:,2]
green = resized[:,:,1]
blue = resized[:,:,0]
cv2.imshow("Imagew", resized)
cv2.imshow("b", blue)
cv2.imshow("g", green)
cv2.imshow("red", red)
cv2.waitKey(0)