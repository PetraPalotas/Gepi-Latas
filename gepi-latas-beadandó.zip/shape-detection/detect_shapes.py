# Használat
# python detect_shapes.py --image shapes_and_colors.png

# Modulok importálása
import argparse
import imutils
import cv2
import numpy as np
class ShapeDetector:
	def __init__(self):
		pass

	def detect(self, c, mode = 1):
		shape = "Nem lehet azonositani"
		peri = cv2.arcLength(c, True)
		# ha az objektum kissebb mint a limit nem adjuk vissza
		print(peri)
		if peri < 100:
			return shape
		approx = cv2.approxPolyDP(c, 0.04 * peri, True)

		# Ha az alkzatnak 3 csúcsa van akkorhárom szög
		if len(approx) == 3:
			if mode == 1:
				shape = "elsobsegadas"
			else:
				return shape

		# Ha az adott alakzat 4 csúcsot tartalmaz akkor nyégszögletü alkzat,
		# négyzet
		elif len(approx) == 4:
			# compute the bounding box of the contour and use the
			# bounding box to compute the aspect ratio
			(x, y, w, h) = cv2.boundingRect(approx)
			ar = w / float(h)

			# a négyzet oldalainak arányai megközelítőleg egyformák
			# ha egyformák az oldal hosszak akkor négyzet, különben téglalap
			if mode == 2:
				shape = "főút"
				shape = "négyzet" if ar >= 0.95 and ar <= 1.05 else "téglalap"
				print(len(approx))

			else:
				return shape

			if mode == 4:
				shape = "egy írányú"
				shape = "négyzet" if ar >= 0.95 and ar <= 1.05 else "téglalap"
				print(len(approx))

			else:
				return shape

		elif (len(approx) > 5) and (len(approx) < 9 ) :
			if mode == 1:
				shape = "STOP-tabla"
				print(len(approx))
			else:
				return shape
			#exit()

		# Feltételezük hogy az alak egy kör
		else:
			if mode == 3:
				shape = "behajtani tilos"
				print(len(approx))
			else:
				return shape

		# visszatér az alakzat nevével
		print(shape)
		return shape


ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True,
	help="path to the input image")
args = vars(ap.parse_args())

# bemeneti kép
image = cv2.imread(args["image"])
# átméretezett kép
resized = imutils.resize(image, width=700)

ratio = image.shape[0] / float(resized.shape[0])
red = resized[:,:,2]
green = resized[:,:,1]
blue = resized[:,:,0]


# innentől nem egységesek a lépések

for mode in range(5):
	I0_m = np.zeros(red.shape)
	I0 = np.zeros(red.shape)
	# elsőbségadás 1
	# kondíció hogy piros / fehér részek maradjanak csak meg
	if mode == 1:
		I0_rw = (red > 150) & ((green < 85) | (235 < green)) & ((blue < 85) | (235 < blue))
		I0 = red*I0_rw
		gray = I0
		blurred = cv2.GaussianBlur(gray, (21, 21), 0)
		thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)[1]

	elif mode == 2:
		# itt keresek stop táblát 2
		I0_rw = (red > 150) & ((green < 110) ) & ((blue < 110))
		I0 = red*I0_rw
		gray = I0
		blurred = cv2.GaussianBlur(gray, (21, 21), 0)
		thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)[1]

	elif mode == 3:
	# főút 3
		I0_rw = (red > 75) & ((green > 75) ) & ((blue < 25))
		I0 = red*I0_rw
		gray = I0
		blurred = cv2.GaussianBlur(gray, (21, 21), 0)
		thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)[1]

	# behajtani tilos 4
	elif mode == 4:
		I0_rw = (red > 110) & ((green <30) ) & ((blue < 30))
		I0 = red*I0_rw
		gray = I0
		blurred = cv2.GaussianBlur(gray, (21, 21), 0)
		thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)[1]
	elif mode == 5:
		# egy iranyu 5
		I0_rw =((red < 55) & ((green < 55) ) & ((blue > 115))) & ((green < 85) | (235 < green)) & ((blue < 85) | (235 < blue))
		I0_o = np.ones(red.shape)
		I0 = I0_o*I0_rw
		gray = I0

		blurred = cv2.GaussianBlur(gray, (121, 121), 0)

		b = blurred>0.4
		b = (b*red)+(b*blue)

	#thresh = cv2.threshold(blurred, 60, 255, cv2.THRESH_BINARY)[1]
		thresh=b

	cv2.imshow("Image", resized)
	cv2.imshow("red", red)
	cv2.imshow("I0_m", I0)
	cv2.imshow("gal", blurred)
	cv2.imshow("tre", thresh)

	cv2.waitKey(0)
	# kontúrkeresés
	cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,
		cv2.CHAIN_APPROX_SIMPLE)
	cnts = imutils.grab_contours(cnts)
	sd = ShapeDetector()
	# loop over the contours
	for c in cnts:
		# compute the center of the contour, then detect the name of the
		# shape using only the contour
		M = cv2.moments(c)
		cX = int((M["m10"] / M["m00"]) * ratio)
		cY = int((M["m01"] / M["m00"]) * ratio)
		shape = sd.detect(c)
		# Átméretezéshez meg szorozuk a kontur (x, y) kordinátáit
		# majd meg rajzolja a konturokat és az alakzat nevét kiírja
		c = c.astype("float")
		c *= ratio
		#if shape == "triangle":
			#print(c)
		if shape == "Nem lehet azonositani":
			continue
		c = c.astype("int")
		cv2.drawContours(image, [c], -1, (0, 255, 0), 2)
		cv2.putText(image, shape, (cX, cY), cv2.FONT_HERSHEY_SIMPLEX,
			0.5, (255, 255, 255), 2)

		# meg jelenti a képernyőn a kimeneti képeket
		cv2.imshow("Image", image)
		resized = imutils.resize(image, height=800)
		cv2.imshow("Imagew", resized)
		cv2.imshow("red", red)
		cv2.waitKey(0)
		cv2.destroyAllWindows()
